/* 

Instanceof Operator in java with a variable that has null value.

*/

package Day28;

class Cat 
{
    public static void main(String[] args) {
        Cat c = null;
        System.out.println(c instanceof Cat);
    }

}
