
// Write a program to understand the concept of for each loop which is used for array.

public class Foreach 
{
    public static void main(String[] args) {
        String names [] = {"C","C++","Java","Python"};
        for(String name:names)
        {
            System.out.println(name);
        }
    }    
}
