// Write a program to understand the concept of for loop.

public class For
{
    public static void main(String[] args) {
        int i;
        
        for(i = 1; i <= 10; i++)
        {

            System.out.println(i);
        }
    }
}
