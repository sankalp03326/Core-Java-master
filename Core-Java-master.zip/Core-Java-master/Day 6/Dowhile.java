
// Write a program to print the first 10 even number by do while loop.

public class Dowhile 
{
    public static void main(String[] args) {
        int i = 0;
        do
        {
            System.out.println(i);
            i = i + 2;
        }
        while(i <= 10);
    }    
}
