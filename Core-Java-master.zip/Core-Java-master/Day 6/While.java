// Write a program to find the first 10 even number. 

public class While 
{
   public static void main(String[] args) {
       int i = 0;
       while(i<=10)
       {
           System.out.println(i);
           i = i + 2;
       }
   }
}
