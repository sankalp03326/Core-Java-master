// Write a program to define the for each loop 

// For each loop is used to traverse an array or collection in java.


public class Foreachloop 
{
    public static void main(String[] args) {
        int[] arr = {12, 34, 45, 44,32, 78};

        for(int i: arr)
        {
            System.out.println(i);
        }
    }
}
