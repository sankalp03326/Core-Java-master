
// Infinitive for loop
/*
If we put two ;; in the for loop syntax then it execute the loop in infinite times such as -
for(;;)
*/

public class Infinitivefor {
    public static void main(String[] args) {
        for(;;)
        {
            System.out.println("Infinitive loop");

            // Use CTRL + C to stop the infinte loop.
        }
    }
}
