/*

Do-while Infinite loop
Syntax - 
do
{
    // Statement to be executed 
    incr/decr;
}
while(true);

*/

public class DowhileInfinite 
{
    public static void main(String[] args) {
        do
        {
            System.out.println("Do-while Infinite loop");
        }
        while(true);
    }    
}
