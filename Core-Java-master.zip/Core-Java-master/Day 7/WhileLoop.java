
// Write a program to define the concept of while loop.

/*
When we need to iterate a part of the program and the no. of iteration is not fixed then it is 
recommended to use the while loop.
*/

public class WhileLoop 
{
    public static void main(String[] args) {
        int i = 1;

        while(i<=10)
        {
            System.out.println(i);
            i++;
        }
    }    
}
