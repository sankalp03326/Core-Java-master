/*
Syntax for infinite while loop.

while(true)
{
    // Statements to be executed.
}
*/

public class WhileInfinite 
{
    public static void main(String[] args) {
        while(true)
        {
            System.out.println("Infinite");
        }
    }    
}
