/*
Two types of method in java
-> Predefined Method
-> User-defined Method
*/
// Write a program to demonstrate the use of Predefined method.

class PredefinedM
{
    public static void main(String[] args) {

        System.out.println(Math.max(4,5));
        // Max is a predefined method here which is exist in Math package.
    }
}