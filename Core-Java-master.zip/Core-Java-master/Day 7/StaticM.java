
// Write a program to demonstrate the use of static method.

class Display  
{
    static void disp()
    {
        System.out.println("Static method");
    }    
    public static void main(String[] args) {
        disp();
    }    
}
