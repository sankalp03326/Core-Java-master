// Write a program to understand the concept of Default Constructor.

class Student 
{
    Student()
    {
        System.out.println("Default Constructor");
    }
    public static void main(String[] args) {
        // Create the instance of the class
        Student s1 = new Student();
        
    }
}
