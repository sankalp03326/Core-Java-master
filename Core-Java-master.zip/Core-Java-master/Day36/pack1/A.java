
// -> Access the package by importing packagename.classname

package Day36.pack1;

public class A 
{
    // define a method
    public void printMsg()
    {
        System.out.println("Hello I'm from class A");
    }    
}
