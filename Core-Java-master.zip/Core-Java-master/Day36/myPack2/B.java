package Day36.myPack2;

public class B 
{
    public static void main(String[] args) {
        // Create an instance of the class A 
        Day36.pack2.A obj = new Day36.pack2.A();

        // invoke method 
        obj.msg();
    }    
}
