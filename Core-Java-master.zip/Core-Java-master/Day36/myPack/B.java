
// -> import package.*; 

package Day36.myPack;

import Day36.pack.A;

class B 
{
    public static void main(String[] args) {
        // Create an instance of the class A 
        A obj = new A();

        obj.msg();
    }    
}
