// Write a program to print the ASCII value of all alphabet (A to Z).

package ASCIIValue;

public class ASCIIEX_6 
{
    public static void main(String s[])
    {
        int i;
        for(i = 65; i <= 90; i++)
        {
            System.out.println("The ASCII value of "+ " "+ (char)i+" "+ "is:" + " "+ i);
        }
    }   
}
