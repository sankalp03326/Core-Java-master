
/* Write a simple program to print the ASCII value. */
package ASCIIValue;

public class ASCIIEX_3 
{
    public static void main(String s[])
    {
        int ch1 = 'a';
        int ch2 = 'b';

        System.out.println("The ASCII value of ch1 is "+ ch1);
        System.out.println("The ASCII value of ch2 is "+ ch2);
    }
}
