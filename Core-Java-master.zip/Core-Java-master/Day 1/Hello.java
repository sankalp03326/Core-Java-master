// Write a program to print the Hello World.
class Hello
{
    public static void main(String s[])
    {
        System.out.println("Hello Java World !");
    }
}