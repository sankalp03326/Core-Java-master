package Day42;
public class Recursion {  

    static void p(){  
    System.out.println("hello");  
    p();  
    }  
      
    public static void main(String[] args) {  
    p();  
    }  
}